            <ul>
                <li>
                    <a href="#" class="active">Home</a>
                </li>
                <li>
                    <a href="#">Cannon</a>
                </li>
                <li>
                    <a href="#">Explosive</a>
                </li>
                <li>
                    <a href="#">Misc</a>
                </li>
                <li>
                    <a href="#">Rocket</a>
                </li>
                <li>
                    <a href="#">Trap</a>
                </li>
            </ul>