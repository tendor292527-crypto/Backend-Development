<!-- <ul>
                <li>
                    <a href="/index.php" title="Acme Home Page"class="active">Home</a>
                </li>
                <li>
                    <a href="#" title="Cannons in our inventory">Cannon</a>
                </li>
                <li>
                    <a href="#" title="Explosives in our inventory">Explosive</a>
                </li>
                <li>
                    <a href="#" title="miscellaneus items in our inventory">Misc</a>
                </li>
                <li>
                    <a href="#" title="Rockets in our inventory">Rocket</a>
                </li>
                <li>
                    <a href="#" title="Traps in our inventory">Trap</a>
                </li>
            </ul> -->
            <?php echo $navList; ?>