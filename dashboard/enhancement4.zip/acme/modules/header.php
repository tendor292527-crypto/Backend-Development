<div>
        <a href="/dashboard/acme/index.php"><img class="logo" src="/dashboard/acme/images/site/logo.jpg" title="Acme Logo" alt="Acme Logo"></a>
    </div>
    <div id="myAccount">
        <a href="/dashboard/acme/accounts/index.php?action=login"><img class="account" src="/dashboard/acme/images/site/account.jpg" title="My Account Menu" alt="My Account Folder">
         <span>My Account</span></a>
    </div>