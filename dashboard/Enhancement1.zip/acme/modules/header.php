    <div>
        <a href="#"><img class="logo" src="/dashboard/acme/images/site/logo.jpg" alt="Acme Logo"></a>
    </div>
    <div id="myAccount">
        <a href="#"><img class="account" src="/dashboard/acme/images/site/account.jpg" alt="My Account Folder">
         <span>My Account</span></a>
    </div>
