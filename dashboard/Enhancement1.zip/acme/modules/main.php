            <h1>Welcome To Acme!</h1>
            <div class="showcase">
                <article>
                    <ul>
                        <li>
                            <h2>Acme Rocket</h2>
                        </li>
                        <li>Quick lighting fuse</li>
                        <li>NHTSA approved seat belts</li>
                        <li>Mobile launch stand included</li>
                        <li><a href="#"><img id="iWantIt" src="/dashboard/acme/images/site/iwantit.jpg" alt="Add to cart button"></a></li>
                    </ul>
                </article>
        </div>

            <div class="section1">
                <article class="article1 article">
                    <h2>Feature Recipes</h2>
                    <div>
                        <div>
                            <img src="/dashboard/acme/images/recipes/bbqsand.jpg" alt="Roatrunner BBQ Sandwhich">
                            <a href="#">Pulled Roadrunner BBQ</a>
                        </div>
                        <div>
                            <img src="/dashboard/acme/images/recipes/potpie.jpg" alt="Roadrunner Pot Pie">
                            <a href="#" >Roadrunner Pot Pie</a>
                        </div>
                        <div>
                            <img src="/dashboard/acme/images/recipes/soup.jpg" alt="Roadrunner Soup">
                            <a href="#" >Roadrunner Soup</a>
                        </div>
                        <div>
                            <img src="/dashboard/acme/images/recipes/taco.jpg" alt="Roadrunner Taco">
                            <a href="#" >Roadrunner Tacos</a>
                        </div>
                    </div>
                </article>
                <article class="article2 article">
                    <div>
                        <h2>Acme Rocket Reviews</h2>
                        <ul>
                            <li>"I don't know how I ever caught roadrunners before this." (4/5)</li>
                            <li>"That thing was fast!" (4/5)</li>
                            <li>"Talk about fast delivery." (5/5)</li>
                            <li>"I didn't even have to pull the meat apart." (4.5/5)</li>
                            <li>"I'm on my thirtieth one. I love these things!" (5/5)</li>
                        </ul>
                    </div>
                </article>
        </div>
